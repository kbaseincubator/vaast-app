# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class PhylotreeDash(Component):
    """A PhylotreeDash component.
Phylotree Dash component.

Generate a phylogenetic tree for a newick string and apply layout changes based on provided
metadata, taxonomic ranks, and other properties.

Keyword arguments:

- id (string; required):
    The ID used to identify this component in Dash callbacks.

- colors (list; default ['#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#ffff33', '#a65628', '#f781bf']):
    List of colors with which to color ranks.

- display_rings (list; optional):
    Boolean array describing if ring should be displayed. Should be
    same length as `rings`.

- display_visualize_button (boolean; default True):
    Display the 'Visualize' button.

- height (string; default "90vh"):
    Height of tree component.

- left_offset (number; default -50):
    Left margin value (negative values move plot closer to left edge).

- max_radius (number; default 500):
    Maximum radius of tree.

- metadata (dict; optional):
    Object corresponding to assignments for each ID in the newick
    tree.  {id: {rank: \"\", ..., traits: {color: \"\", size: 0..1,
    rings: []}}}  Traits are used within the tree to generate node
    bubble `size` (0 or 1) and `color` (hex string).  `rank` is
    expected to be a member of the ``ranks`` array argument  Currently
    supported trait fields:    \"size\":   1 (integer) corresponds to
    this Component's `trait_bubble_size`    \"color\":  color string
    for node    \"rings\":  node value within each ring defined by
    Component's ``rings``. In `categorical` rings, these   values
    represent indices in the list of `values` for that ring. In
    `linear` rings, these values will   be used to interpolate a color
    based on that ring's `values` colors list.

- n_clicks (number; default 0):
    Number of times `Visualize` has been clicked.

- newick (string; default ""):
    Tree formatted as a newick string.

- ranks (list; optional):
    List of tax ranks.

- rings (list; optional):
    Define data to render for rings around tree. Should be same length
    as `display_rings`.  The array should contain objects that define
    information about each ring:  {kind: \"categorical\", colors:
    [\"color\", \"color\", \"color\"], legend_label: \"\",
    legend_color: \"\"}  {kind: \"linear\", colors: [\"color\",
    \"color\", \"color\"], legend_label: \"\", legend_color: \"\"}
    When `kind` == \"categorical\", each color in `colors` is a
    category color.  When `kind` == \"linear\", colors in `colors`
    will be used to create a color scheme.

- selected_nodes (list; optional):
    List of currently selected nodes in phylo tree.

- starting_rank (string; default "genus"):
    Taxonomic rank at which to display bubbles.

- trait_bubble_size (number; default 3):
    Size to render bubbles that have trait annotations.

- width (string; default "100%"):
    Width of tree component."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'phylotree_dash'
    _type = 'PhylotreeDash'
    @_explicitize_args
    def __init__(self, id=Component.REQUIRED, newick=Component.UNDEFINED, metadata=Component.UNDEFINED, rings=Component.UNDEFINED, display_rings=Component.UNDEFINED, starting_rank=Component.UNDEFINED, ranks=Component.UNDEFINED, selected_nodes=Component.UNDEFINED, n_clicks=Component.UNDEFINED, colors=Component.UNDEFINED, trait_bubble_size=Component.UNDEFINED, left_offset=Component.UNDEFINED, max_radius=Component.UNDEFINED, display_visualize_button=Component.UNDEFINED, height=Component.UNDEFINED, width=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'colors', 'display_rings', 'display_visualize_button', 'height', 'left_offset', 'max_radius', 'metadata', 'n_clicks', 'newick', 'ranks', 'rings', 'selected_nodes', 'starting_rank', 'trait_bubble_size', 'width']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'colors', 'display_rings', 'display_visualize_button', 'height', 'left_offset', 'max_radius', 'metadata', 'n_clicks', 'newick', 'ranks', 'rings', 'selected_nodes', 'starting_rank', 'trait_bubble_size', 'width']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['id']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(PhylotreeDash, self).__init__(**args)
